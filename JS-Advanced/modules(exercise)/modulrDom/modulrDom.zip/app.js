/**
 * Created by MARK-Max on 10.11.2016 г..
 */
result.BaseElement = require('./baseElement.js');
result.TitleBar = require('./titleBar');
result.Footer = require('./footer');
result.Article = require('./article');
result.ImageArticle = require('./imageArticle');
result.TableArticle = require('./tableArticle');