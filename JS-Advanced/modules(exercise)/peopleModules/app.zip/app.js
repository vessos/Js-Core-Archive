/**
 * Created by MARK-Max on 9.11.2016 г..
 */
result.Employee = require('./employee');
result.Junior = require('./junior');
result.Manager = require('./menager');
result.Senior = require('./senior');