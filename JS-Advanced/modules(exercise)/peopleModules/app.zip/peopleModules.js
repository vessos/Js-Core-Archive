/**
 * Created by MARK-Max on 9.11.2016 г..
 */
function createPeopleClasses() {
    return {Employee, Junior, Senior, Manager};
}