/**
 * Created by MARK-Max on 9.11.2016 г..
 */
result.Turtle = require('./turtles');
result.EvkodianTurtle = require('./evkodianTurtles');
result.GalapagosTurtle = require('./galapagosTurtle');
result.NinjaTurtle = require('./ninjaTurtles');
result.WaterTurtle = require('./waterTurtle');