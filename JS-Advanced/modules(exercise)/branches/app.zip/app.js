/**
 * Created by MARK-Max on 9.11.2016 г..
 */
result.Employee = require('./employee');
result.Branch = require('./branches');