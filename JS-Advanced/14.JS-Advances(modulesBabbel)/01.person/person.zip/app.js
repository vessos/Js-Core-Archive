/**
 * Created by MARK-Max on 4.11.2016 г..
 */
let Person=require('./person');
result.Person = Person.Person
let p = new Person.Person("ChristopherRobin");

console.log(p.toString())
