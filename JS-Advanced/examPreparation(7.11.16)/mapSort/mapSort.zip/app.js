/**
 * Created by MARK-Max on 9.11.2016 г..
 */
let mapSort = require('./mapSort');
result.mapSort = mapSort;