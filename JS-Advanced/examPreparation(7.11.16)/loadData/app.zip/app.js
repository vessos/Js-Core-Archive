/**
 * Created by MARK-Max on 9.11.2016 г..
 */
let functions = require('./loadData');

result.sort = functions.sort;
result.filter = functions.filter;